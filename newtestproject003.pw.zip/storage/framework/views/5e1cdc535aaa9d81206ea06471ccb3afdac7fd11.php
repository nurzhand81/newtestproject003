<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><a href="<?php echo e(route('categories.show', $category->id)); ?>"><?php echo e($category->name); ?></a></h2>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\newtestproject003.pw\resources\views/categories/index.blade.php ENDPATH**/ ?>