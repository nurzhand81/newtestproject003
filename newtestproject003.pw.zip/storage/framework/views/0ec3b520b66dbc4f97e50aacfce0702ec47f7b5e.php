<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Trashed Blogs</h1>
        </div>
    </div>
    <div class="col-md-12">
        <?php $__currentLoopData = $trashedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2><?php echo e($blog->title); ?></h2>
            <p><?php echo e($blog->body); ?></p>

        
        <div class="btn-group">
        <form method="get" action="<?php echo e(route('blogs.restore', $blog->id)); ?>">
            <button type="submit" class="btn btn-success btn-xs pull-left btn-margin-right">
                Restore
            </button>
            <?php echo e(csrf_field()); ?>

        </form>
            
            <form method="post" action="<?php echo e(route('blogs.permanent-delete', $blog->id)); ?>">
                <?php echo e(method_field('delete')); ?>

                <button type="submit" class="btn btn-danger btn-xs pull-left btn-margin-right">
                    Permanent delete
                </button>
                <?php echo e(csrf_field()); ?>

            </form>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\newtestproject003.pw\resources\views/blogs/trash.blade.php ENDPATH**/ ?>