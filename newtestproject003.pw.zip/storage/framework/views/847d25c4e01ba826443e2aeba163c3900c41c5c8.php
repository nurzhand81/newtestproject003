<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <article>

        <div class="jumbotron">

            <div class="col-md-12">
                <?php if($blog->featured_image): ?>
                    <img src="images/featured_image/<?php echo e($blog->featured_image ? $blog->featured_image : ''); ?>"
                    alt="<?php echo e(\Illuminate\Support\Str::limit($blog->title, 50)); ?>"
                    class="img-responsive featured_image">
                <?php endif; ?>
            </div>

            <div class="col-md-12">
            <h1><?php echo e($blog->title); ?></h1>
            </div>

            <div class="col-md-12">
                <div class="btn-group">
            <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>"
               class="btn btn-primary btn-sm pull-left btn-margin-right btn-margin-right">Edit</a>

            <form method="post" action="<?php echo e(route('blogs.delete', $blog->id)); ?>"><?php echo e(method_field('delete')); ?>

                <button type="submit" class="btn btn-danger btn-sm pull-left">Delete</button>
                <?php echo e(csrf_field()); ?>

            </form>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <p><?php echo e($blog->body); ?></p>
        </div>

        </article>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\newtestproject003.pw\resources\views/blogs/show.blade.php ENDPATH**/ ?>