<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h1><?php echo e($category->name); ?></h1>

        <div class="btn-group">
        <a href="<?php echo e(route('categories.edit', $category->id)); ?>"
        class="btn btn-warning btn-sm btn-margin-right">Edit</a>

        <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="post">
            <?php echo e(method_field('delete')); ?>

                <button type="submit" class="btn btn-danger btn-sm pull-left">Delete</button>
            <?php echo e(csrf_field()); ?>

        </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\newtestproject003.pw\resources\views/categories/show.blade.php ENDPATH**/ ?>