<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="jumbotron">
            <h1>Create a category</h1>
        </div>
        <div class="col-md-12">
            <form action="<?php echo e(route('categories.store')); ?>" method="post">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control">
                </div>

                <button class="btn btn-primary" type="submit">Create a new category</button>
                <?php echo e(csrf_field()); ?>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\newtestproject003.pw\resources\views/categories/create.blade.php ENDPATH**/ ?>