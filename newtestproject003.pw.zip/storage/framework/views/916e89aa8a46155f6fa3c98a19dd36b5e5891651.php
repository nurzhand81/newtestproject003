<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><a href=<?php echo e(route('blogs.show', $blog->id)); ?>><?php echo e($blog->title); ?></a></h2>
    <p><?php echo e($blog->body); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\newtestproject003.pw\resources\views/blogs/index.blade.php ENDPATH**/ ?>