<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
    <div class="jumbotron">
        <h1>Admin Dashboard</h1>
    </div>
        <div class="col-md-12">
            <button class="btn btn-margin-right">
                <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary btn-lg btn-margin-right">Create Blog</a>
            </button>

            <button class="btn btn-margin-right">
                <a href="<?php echo e(route('blogs.trash')); ?>" class="btn btn-danger btn-lg btn-margin-right">Trashed Blogs</a>
            </button>

            <button class="btn btn-margin-right">
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success btn-lg btn-margin-right">Create category</a>
            </button>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\newtestproject003.pw\resources\views/admin/index.blade.php ENDPATH**/ ?>